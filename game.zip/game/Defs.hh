#define GAME_NAME "TheWalkingDead"
#define VERSION   "1.0"
